#include <iostream>
#include <stack>
#include <sstream>
#include <cctype>

using namespace std;

class BET
{
public:
    BET();
    BET(const string &postfix);
    BET(const BET &copy);
    ~BET();
    bool buildFromPostfix(const string &postfix);
    const BET &operator=(const BET &bt);
    void printInfixExpression() const;
    void printPostfixExpression() const;
    size_t size() const;
    size_t leaf_nodes() const;
    bool empty() const;

private:
    struct BinaryNode
    {
        string element;
        BinaryNode *left;
        BinaryNode *right;

        BinaryNode(const string &theElement, BinaryNode *lt, BinaryNode *rt)
            : element(theElement), left(lt), right(rt) {}
    };

    BinaryNode *root;

    void printInfixExpression(BinaryNode *n) const;
    void printPostfixExpression(BinaryNode *n) const;
    void makeEmpty(BinaryNode *&t);
    BinaryNode *clone(BinaryNode *t) const;
    size_t size(BinaryNode *t) const;
    size_t leaf_nodes(BinaryNode *t) const;
};
