#include <iostream>
#include <sstream>
#include <stack>

#include "bet.h"

using namespace std;

BET::BET() : root(nullptr) {}

BET::BET(const string &postfix) : root(nullptr)
{
    if (!buildFromPostfix(postfix))
    {
        cout << "Error: Invalid postfix expression." << endl;
    }
}

BET::BET(const BET &copy) : root(clone(copy.root)) {}

BET::~BET()
{
    makeEmpty(root);
}

bool BET::buildFromPostfix(const string &postfix)
{
    if (root != nullptr)
    {
        makeEmpty(root);
    }

    stack<BinaryNode *> s;
    istringstream ss(postfix);
    string token;

    while (ss >> token)
    {
        if (isalnum(token[0]))
        {
            s.push(new BinaryNode(token, nullptr, nullptr));
        }
        else
        {
            if (s.size() < 2)
            {
                return false;
            }
            BinaryNode *right = s.top();
            s.pop();
            BinaryNode *left = s.top();
            s.pop();
            s.push(new BinaryNode(token, left, right));
        }
    }

    if (s.size() != 1)
    {
        return false; // Invalid expression
    }

    root = s.top();
    return true;
}

const BET &BET::operator=(const BET &bt)
{
    if (this != &bt)
    {
        makeEmpty(root);
        root = clone(bt.root);
    }
    return *this;
}

BET::BinaryNode *BET::clone(BinaryNode *t) const
{
    if (t == nullptr)
        return nullptr;
    return new BinaryNode(t->element, clone(t->left), clone(t->right));
}

void BET::makeEmpty(BinaryNode *&t)
{
    if (t != nullptr)
    {
        makeEmpty(t->left);
        makeEmpty(t->right);
        delete t;
        t = nullptr;
    }
}

void BET::printInfixExpression() const
{
    if (!empty())
    {
        printInfixExpression(root);
        cout << endl;
    }
}

void BET::printInfixExpression(BinaryNode *n) const {
    if (n != nullptr) {

        bool leftNeedsParens = n->left && 
            (n->left->element == "+" || n->left->element == "-") &&
            (n->element == "*" || n->element == "/");


        bool rightNeedsParens = n->right && 
            (n->right->element == "+" || n->right->element == "-") &&
            (n->element == "*" || n->element == "/" || n->element == "+" || n->element == "-");


        if (leftNeedsParens) cout << "(";
        printInfixExpression(n->left);
        if (leftNeedsParens) cout << ")";

        cout << " " << n->element << " ";

        if (rightNeedsParens) cout << "(";
        printInfixExpression(n->right);
        if (rightNeedsParens) cout << ")";
    }
}



void BET::printPostfixExpression() const
{
    if (!empty())
    {
        printPostfixExpression(root);
        cout << endl;
    }
}

void BET::printPostfixExpression(BinaryNode *n) const
{
    if (n != nullptr)
    {
        printPostfixExpression(n->left);
        printPostfixExpression(n->right);
        cout << n->element << " ";
    }
}

size_t BET::size() const
{
    return size(root);
}

size_t BET::size(BinaryNode *t) const
{
    if (t == nullptr)
        return 0;
    return 1 + size(t->left) + size(t->right);
}

size_t BET::leaf_nodes() const
{
    return leaf_nodes(root);
}

size_t BET::leaf_nodes(BinaryNode *t) const
{
    if (t == nullptr)
        return 0;
    if (t->left == nullptr && t->right == nullptr)
        return 1;
    return leaf_nodes(t->left) + leaf_nodes(t->right);
}

bool BET::empty() const
{
    return root == nullptr;
}